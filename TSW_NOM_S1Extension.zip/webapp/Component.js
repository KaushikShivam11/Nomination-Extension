jQuery.sap.declare("oil.tsw.mynominationss1.TSW_NOM_S1Extension.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "oil.tsw.mynominationss1",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on SAPUI5 ABAP Repository
	url: "/sap/bc/ui5_ui5/sap/TSW_NOM_S1"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.oil.tsw.mynominationss1.Component.extend("oil.tsw.mynominationss1.TSW_NOM_S1Extension.Component", {
	metadata: {
		manifest: "json"
	}
});