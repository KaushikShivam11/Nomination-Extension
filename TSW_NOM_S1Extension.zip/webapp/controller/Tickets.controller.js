sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, MessageBox, History, Fragment, MessageToast, MessagePopover, MessagePopoverItem, Filter,
	FilterOperator) {
	"use strict";

	return Controller.extend("oil.tsw.mynominationss1.TSW_NOM_S1Extension.controller.Tickets", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.view.Tickets
		 */
		onInit: function () {
			sap.ui.core.UIComponent.getRouterFor(this).getRoute("Tickets").attachPatternMatched(function (e) {
				var n = e.getParameter("arguments").nom_key;
				var g = e.getParameter("arguments").nom_item;
				var oDataModel = this.getOwnerComponent().getModel();
				var oFilterKey = new Filter("Nomtk", FilterOperator.EQ, n);
				var oFilterItem = new Filter("Nomit", FilterOperator.EQ, g);
				var oFilterAll = new Filter({
					filters: [oFilterKey, oFilterItem],
					and: true
				});
				oDataModel.read("/TicketDetailSet", {
					filters: [oFilterAll],
					success: function (oData) {
						var oDataLcal = oData;
						var oTanksModel = new JSONModel(oDataLcal.results);
						this.getView().setModel(oTanksModel, "ticketModel");
						this.getView().byId("idTicketTable").bindRows("ticketModel>/");
					}.bind(this),
					error: function (error) {
						var oError = error;
					}
				});
			}, this);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.view.Tickets
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.view.Tickets
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.view.Tickets
		 */
		//	onExit: function() {
		//
		//	}

	});

});