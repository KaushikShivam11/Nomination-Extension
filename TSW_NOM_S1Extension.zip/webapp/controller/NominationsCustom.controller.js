sap.ui.controller("oil.tsw.mynominationss1.TSW_NOM_S1Extension.controller.NominationsCustom", {

	/**
	 * Called when a controller is instantiated and its View controls (if available) are already created.
	 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.controller.NominationsCustom
	 */
	mFilterItems: {
		NomNum: "NominationNum",
		NomKey: "NominationKey",
		NomItem: "NominationItem",
		NomTyp: "NomType",
		FlagImex: "FlagImex",
		LocId: "LocationId",
		VehicleNum: "VehicleNum",
		Docnr: "Document Number",
		Material: "Material",
		Shipper: "Shipper",
		Carrier: "Carrier",
		BatchDest: "Batch Destination",
		BatchOrigin: "Batch Origin",
		SchldMaterial: "Scheduled Material",
		DelInd: "Deletion Indicator",
		InTransitLoc: "In Transit S Location",
		InTransitPlant: "In transit Plant",
		WrkListInd: "Worklist Indicator",
		ValTypDestination: "Valuationtype_d",
		ValTypOrigin: "Valuationtype_o",
		TransportPlanPt: "TransportPlanningPt",
		ImpoExpo: "ImpoExpo",
		UoM: "UoM",
		PersonName: "PersonName",
		ContractPrtnr: "ContractPrtnr",
		ConsigneePrtnr: "ConsigneePrtnr",
		RefDocInd: "RefDocIndicator",
		LocationPtnr: "Location Partner",
		RefDocItem: "RefDocItem",
		IncompleteFlag: "IncompleteFlag",
		Istat: "Istat",
		Tsyst: "Transport System",
		Inspector: "Inspector",
		ItemSubStatus: "ItemSubSt",
		QuickConfirm: "QuickConfirm",
		ChangedOn: "ChangedOn",
		Status: "Status",
		Sityp: "Schedule Type",
		RecordDate: "RecordCreateDate",
		TSTFrom: "ScheduledTSTFrom",
		TSTTo: "ScheduledTSTTo",
		SchdlDate: "ScheduledDate",
		CycleID: "CycleID",
		RefDocType: "RefDocType",
		SchedQty: "SchedQty",
		TDVehId: "TD vehicle Identifier"
	},

	onInit: function () {
		var oMessageProcessor = new sap.ui.core.message.ControlMessageProcessor();
		var oMessageManager = sap.ui.getCore().getMessageManager();
		oMessageManager.registerMessageProcessor(oMessageProcessor);
		oMessageManager.removeAllMessages();
		this.navCounter = 0;
		this.bNavFlag = true;
		this.oFilterBar = null;
		this._oFilterBarData = null;
		this.nNominationsRowCount = 0;
		this.bNewDataLoaded = true;
		this.aNomItemFilter = [];
		this.bIsFilterApplied = true;
		var oViewModel;
		this.setModel(new sap.ui.model.json.JSONModel({
			bCopyAdv: false,
			nCopyCount: 1,
			bEvents: false,
			bComments: false,
			bLoadDischarge: false,
			sUser: ""
		}), "CopyOptions");
		this.setModel(new sap.ui.model.json.JSONModel({
			aNominationNum: [],
			aNominationKey: [],
			aNominationItem: [],
			aNomType: [],
			aMaterial: [],
			aInTransitLoc: [],
			aInTransitPlant: [],
			aImpoExpo: [],
			aFlagImex: [],
			aIstat: [],
			aDocnr: [],
			aTsyst: [],
			aInspector: [],
			aContractPrtnr: [],
			aStatus: [],
			aSityp: [],
			aUoM: [],
			aSchldMaterial: [],
			aPersonName: [],
			aVehicleNum: [],
			aConsigneePrtnr: [],
			aSelectedImpoExpo: [],
			aTransportPlanningPt: []
		}), "Selections");
		this.setModel(new sap.ui.model.json.JSONModel({
			aMessages: [],
			aMessageList: [],
			nLength: 0,
			bType: "Transparent"
		}), "Messages");

		this._getBusyDialog();
		this.getFragmentControl(this._getBusyDialogId(), "tswBusyDialog").open();
		var firstLoad = true;
		this.firstLoad = true;
		this.alreadyset = false;

		this.LoadVariantfromURL();
		this.setAppState();

		this.oFilterBar = this.byId("tswFilterBarNominations");
		this.oFilterBar.registerFetchData(jQuery.proxy(this._fnFetchData, this));
		this.oFilterBar.registerApplyData(jQuery.proxy(this._fnApplyData, this));
		this.oFilterBar.registerGetFiltersWithValues(jQuery.proxy(this._fnGetFiltersWithValues, this));
		this.getRouter().getRoute("NominationsWorklist").attachPatternMatched(this._onNominationsMatched, this);
		this.onToggleSearchField();
		this.oFilterBar.fireInitialise();

		this._getNomNumFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getLocIdFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getScheduledMaterialFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getTransportSystemFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getNomTypeFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getNomKeyFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getNomItemFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getPersonNameFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getUoMFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getValuationTypeDFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getValuationTypeOFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		// this._getStatusFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getSchldTypeFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		// this._getNomStatusFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getTransportPlanningPointFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getVehicleNumFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getMaterialFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getContractPartnerFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getInspectorFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getLocationPartnerFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getShipperFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getCarrierFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getConsigneePartnerFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getDocnrFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getInTransitLocationFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getInTransitPlantFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getRefDocItemFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getImpoExpoFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));
		this._getFlagImexFilter().addValidator(jQuery.proxy(this._fnFilterValidaton, this));

		this.oColumnSorter = {};

		var URLParsing = sap.ushell.Container.getService("URLParsing");
		var sShellHash = URLParsing.getShellHash(location.href);
		var oObject = URLParsing.parseShellHash(sShellHash);

		var url = location;
		var uri;
		if (oObject)
			uri = url.protocol + "//" + url.hostname + url.pathname + url.search + "#" + oObject.semanticObject + "-" + oObject.action;

		oViewModel = new sap.ui.model.json.JSONModel({
			worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
			saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
			shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
			shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject", sap.ushell.Container.getUser().getFullName()),
			shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [sap.ushell.Container.getUser().getFullName(),
				uri
			]),
			tableNoDataText: this.getResourceBundle().getText("tableNoDataText")
		});
		this.setModel(oViewModel, "worklistView");

		/**********************Table personalization***********************/

		//this.getView().getContent()[0].addContent(this._getNominationsTable());
		this.variantControl();

		var sVARIANT_SET = "NominationsTableVariantSet",
			sCONTAINER_KEY = "oil.ups.personalization";

		this._oPersoContainer = null;
		this._oPersoVariantSet = null;
		this._oTablePersonalizer = null;
		this._oTablePersoController = null;
		this.sCurrentVariant = null;
		this.sTABLE_ITEM_NAME = "NominationsTablePersonalization";
		this._oComponent = sap.ui.core.Component.getOwnerComponentFor(this.getView());
		this._oPersonalizationService = sap.ushell.Container.getService("Personalization");

		// get the table control and the button control
		// get a Personalizer
		this._oScope = {
			keyCategory: this._oPersonalizationService.constants.keyCategory.FIXED_KEY,
			writeFrequency: this._oPersonalizationService.constants.writeFrequency.LOW,
			clientStorageAllowed: true
		};
		this._oTablePersonalizer = this._oPersonalizationService.getTransientPersonalizer();
		// create a table personalization controller
		this._oTablePersoController = new sap.ui.table.TablePersoController({
			table: this._getNominationsTable(),
			persoService: this._oTablePersonalizer
		});
		//this._oTablePersoController._bSaveFilters = true;
		this._oPersonalizationService.getContainer(sCONTAINER_KEY, {}, this._oComponent).fail(function () {
			oMessageManager.addMessages(
				new sap.ui.core.message.Message({
					id: "Error",
					message: this.getResourceBundle().getText("persDataFail"),
					title: "Error",
					type: "Error",
					processor: oMessageProcessor
				}));
		}.bind(this)).done(function (oContainer) {
			this._oPersoContainer = new sap.ushell.services.Personalization.VariantSetAdapter(oContainer);

			if (!this._oPersoContainer.containsVariantSet(sVARIANT_SET)) {
				this._oPersoContainer.addVariantSet(sVARIANT_SET);
			}

			this._oPersoVariantSet = this._oPersoContainer.getVariantSet(sVARIANT_SET);
			this.initializeVariantManagement();

		}.bind(this));

		/**********************Table personalization***********************/

	},

	onApplyVariant: function (oEvent) {
		var aFilter = [],
			oFilter = {},
			aSorters = [],
			aFilterBarFilters = [],
			oFreeSearchFilter;
		this._aJobsInProcess = [];
		// 			this.bIsFilterApplied = true;
		this.bNewDataLoaded = false;

		//this.getFragmentControl(this._getBusyDialogId(), "tswBusyDialog").open();
		aFilterBarFilters = this._fnCreateFilters(this._getFilterBar());
		this._oFilterBarData = new sap.ui.model.Filter({
			filters: this._fnCreateFilters(this._getFilterBar()),
			bAnd: true
		});
		oFreeSearchFilter = this._fnGetFreeSearchFilter();
		if (oFreeSearchFilter) {
			aFilterBarFilters.push(oFreeSearchFilter);
		}

		if (aFilterBarFilters.length > 0) {
			oFilter = new sap.ui.model.Filter({
				filters: aFilterBarFilters,
				bAnd: true
			});
			if (oFilter) {
				aFilter.push(oFilter);
			}
		}
		if (this._getNominationsTable().getBinding("rows")) {
			this._getNominationsTable().getBinding("rows").filter(aFilter, "Application");
			this.bIsFilterApplied = true;
		} else {
			aSorters.push(new sap.ui.model.Sorter("NominationCreationDate", true));
			var oDate = this.getView().byId("tswScheduledDate");
			this._getNominationsTable().bindRows({
				path: '/C_Oij06_MyNominations',
				filters: aFilter,
				sorter: aSorters,
				events: {
					"dataReceived": this._fnNominationsDataReceived.bind(this)
				}
			});
		}
		if (this.getModel())
			this._fnCount(aFilter);
	},

	/**
	 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	 * (NOT before the first rendering! onInit() is used for that one!).
	 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.controller.NominationsCustom
	 */
	//	onBeforeRendering: function() {
	//
	//	},

	/**
	 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.controller.NominationsCustom
	 */
	//	onAfterRendering: function() {
	//
	//	},

	/**
	 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	 * @memberOf oil.tsw.mynominationss1.TSW_NOM_S1Extension.controller.NominationsCustom
	 */
	//	onExit: function() {
	//
	//	},

	//	initializeVariantManagement: function(E) {
	//
	//	}
	//	onSelect: function(E) {
	//
	//	}
	//	onSave: function(E) {
	//
	//	}
	//	onManage: function(E) {
	//
	//	}
	//	applyVariant: function(v) {
	//
	//	}
	//	onSaveRenamed: function(p) {
	//
	//	}
	//	_fncheckVariantChange: function() {
	//
	//	}
	//	onPersoNominationsTbl: function() {
	//
	//	}
	//	LoadVariantfromURL: function() {
	//
	//	}
	//	beforeVariantFetch: function(E) {
	//
	//	}
	//	onColumnVisibilityChange: function(E) {
	//
	//	}
	//	onNavBack: function() {
	//
	//	}
	//	onToggleSearchField: function(E) {
	//
	//	}
	_onNominationsMatched: function (oEvent) {
		var aFilter = [],
			oFilter = {},
			aFilterBarFilters = [],
			aNominationNum = [],
			aNominationKey = [],
			aSelectedRunId = [],
			aSelectedKey = [];
		if (!this.alreadyset) {
			this._getNominationsTable().setVisibleRowCount(10);
			aNominationNum = this.getOwnerComponent().fnGetNomExtForNav();
			this._getNomNumFilter().destroyTokens();
			var oModel = this.getView().getModel("Selections");
			if (aNominationNum) {
				if (aNominationNum.length > 0) {
					for (var i = 0; i < aNominationNum.length; i++) {
						aSelectedRunId.push({
							nom_num: aNominationNum[i]["value"]
						});
					}
				}
				oModel.setProperty("/aNominationNum", []);
				oModel.setProperty("/aNominationNum", aSelectedRunId);
			}
			aNominationKey = this.getOwnerComponent().fnGetNomKeyForNav();
			this._getNomKeyFilter().destroyTokens();
			if (aNominationKey) {
				if (aNominationKey.length > 0) {
					for (var j = 0; j < aNominationKey.length; j++) {
						aSelectedKey.push({
							Nomtk: aNominationKey[j]["Low"]
						});
					}
				}
				oModel.setProperty("/aNominationKey", []);
				oModel.setProperty("/aNominationKey", aSelectedKey);
				this._getNominationKeyFilterItem().setVisibleInFilterBar(true);
				this._getNominationKeyFilterItem().setVisible(true);
			}
			this.alreadyset = true;
			this.getFragmentControl(this._getBusyDialogId(), "tswBusyDialog").close();
			//this.onFilterApply(oEvent);
		} else {
			this.getOwnerComponent().fnSetNominationsModified(true);
			sap.ui.getCore().getMessageManager().removeAllMessages();
			if (this.getOwnerComponent().fnGetNominationsModified() === true) {
				this.getOwnerComponent().fnSetNominationsModified(false);
				var aNewNominations = this.getOwnerComponent().fnGetNewNominationsCreated();
				this.bNewDataLoaded = false;
				this.getFragmentControl(this._getBusyDialogId(), "tswBusyDialog").close();
				//this._getNominationsTable().getBinding("rows").refresh();
				/*if (this.getModel()) {
					aFilterBarFilters = this._fnCreateFilters(this._getFilterBar());
					if (aFilterBarFilters.length > 0) {
						oFilter = new sap.ui.model.Filter({
							filters: aFilterBarFilters,
							bAnd: true
						});
						if (oFilter) {
							aFilter.push(oFilter);
						}
					}
					this._fnCount(aFilter);
				}*/
			}
		}
	},
	//	onApplyVariant: function(E) {
	//
	//	}
	//	_fnGetFreeSearchFilter: function() {
	//
	//	}
	//	_getFreeSearchInput: function() {
	//
	//	}
	//	_fnCount: function(f) {
	//
	//	}
	//	onDisplayMessagePopover: function(E) {
	//
	//	}
	onFilterApply: function (oEvent) {
		var oDateValue = this.getView().byId("tswScheduledDate").getFrom();
		if (oDateValue === null) {
			sap.m.MessageBox.error("Please Select the Scheduled Date", {
				onClose: function (oAction) {
					this.getFragmentControl(this._getBusyDialogId(), "tswBusyDialog").close();
				}.bind(this)
			});
			return;
		}
		this.getView().byId("tswTblNominations").bindRows({
			path: '/C_Oij06_MyNominations',
			sorter: [new sap.ui.model.Sorter("NominationCreationDate", true)],
			events: {
				"dataReceived": this._fnNominationsDataReceived.bind(this)
			}
		});
		var oSearchFilter = this._getSearchFilter(),
			aFilters = [],
			aFinalFilter = [],
			oFilter,
			aFilterBarFilters = [];

		var nom = [],
			aNominationExt = [],
			aNavFilter = [];
		nom = this.getOwnerComponent().fnGetNomKeyForNav();
		aNominationExt = this.getOwnerComponent().fnGetNomExtForNav();
		if (nom === undefined && aNominationExt === undefined) {
			//nothing
		} else if (nom !== undefined && nom.length !== 0) {
			for (var i = 0; i < nom.length; i++) {
				aNavFilter.push(new sap.ui.model.Filter("NominationDoc", sap.ui.model.FilterOperator.EQ, nom[i].Low));
			}
		} else if (aNominationExt !== undefined && aNominationExt.length !== 0) {
			for (var i = 0; i < aNominationExt.length; i++) {
				aNavFilter.push(new sap.ui.model.Filter("NominationExtNumber", sap.ui.model.FilterOperator.EQ, aNominationExt[i].value));
			}
		}
		if (oEvent.getParameters().refreshButtonPressed) {
			// Search field's 'refresh' button has been pressed.
			// This is visible if you select any master list item.
			// In this case no new search is triggered, we only
			// refresh the list binding.
			this.onRefresh();
		} else {
			this._oFilterBarData = null;
			aFilterBarFilters = this._fnCreateFilters(this._getFilterBar());
			if (aFilterBarFilters.length > 0) {
				this._oFilterBarData = new sap.ui.model.Filter({
					filters: aFilterBarFilters,
					bAnd: true
				});
				this.bNavFlag = false;
			}
			if (this.navCounter === 0 && aNavFilter.length !== 0) {
				if (aFilters.length === 0 || aFilters === undefined) {
					aFilters = aFilters.concat([new sap.ui.model.Filter(aNavFilter, false)]);
				}
				this.navCounter = 1;
			}
			if (this.navCounter !== 0 && aFilterBarFilters.length === 0 && this.bNavFlag === true) {
				aFilters = aFilters.concat([new sap.ui.model.Filter(aNavFilter, false)]);
			} else if (this._oFilterBarData) {
				aFilters.push(this._oFilterBarData);
			}
			if (oSearchFilter) {
				aFilters.push(oSearchFilter);
			}

			if (aFilters.length > 0) {
				oFilter = new sap.ui.model.Filter({
					filters: aFilters,
					bAnd: true
				});
			}
			if (oFilter) {
				aFinalFilter.push(oFilter);
			}

			this.getFragmentControl(this._getBusyDialogId(), "tswBusyDialog").open();
			this._getNominationsTable().setNoData(this.getResourceBundle().getText("nominationLoading"));
			this._getNominationsTable().getBinding("rows").filter(aFinalFilter, "Application");
			this.bIsFilterApplied = true;
			this.bNewDataLoaded = false;
			if (this.getModel())
				this._fnCount(aFinalFilter);

		}
	},
	onPressEvent: function (oEvent) {
		var index, oBinding, oParams = {},
			nVisible = 0,
			nSelected,
			nRowIndex;
		nVisible = this._getNominationsTable().getProperty("firstVisibleRow");
		nRowIndex = oEvent.getSource().getParent().getId().slice(-1);
		nSelected = parseInt(nVisible) + parseInt(nRowIndex);
		oBinding = this._getNominationsTable().getContextByIndex(nSelected);
		if (oBinding) {
			oParams.Nomtk = oBinding.getProperty("NominationDoc");
			oParams.Nomit = oBinding.getProperty("NominationDocItem");
			oParams.EventType = oBinding.getProperty("NominationEventType");
			// this.getFragmentControl(this._getBusyDialogId(), "tswBusyDialog").open();
			this._getNominationsTable().clearSelection();
			this.getRouter().navTo("Events", {
				nom_key: oParams.Nomtk,
				nom_item: oParams.Nomit
			});
		}
	},
	onPressTanks: function (oEvent) {
		var index, oBinding, oParams = {},
			nVisible = 0,
			nSelected,
			nRowIndex;
		nVisible = this._getNominationsTable().getProperty("firstVisibleRow");
		nRowIndex = oEvent.getSource().getParent().getId().slice(-1);
		nSelected = parseInt(nVisible) + parseInt(nRowIndex);
		oBinding = this._getNominationsTable().getContextByIndex(nSelected);
		if (oBinding) {
			oParams.Nomtk = oBinding.getProperty("NominationDoc");
			oParams.Nomit = oBinding.getProperty("NominationDocItem");
			this._getNominationsTable().clearSelection();
			this.getRouter().navTo("Tanks", {
				nom_key: oParams.Nomtk,
				nom_item: oParams.Nomit
			});
		}
	},

	formatDate: function (date) {
		var d = new Date(date),
			month = '' + (d.getMonth() + 1),
			day = '' + d.getDate(),
			year = d.getFullYear();

		if (month.length < 2)
			month = '0' + month;
		if (day.length < 2)
			day = '0' + day;

		return [day, month, year].join('');
	},

	onExport: function () {
		var aCols, aProducts, oSettings, oSheet;

		aCols = this.createColumnConfig();
		var sDateFrom = this.formatDate(this.getView().byId("tswScheduledDate").getFrom());
		var sDateTo = this.formatDate(this.getView().byId("tswScheduledDate").getTo());
		var oFilterKey = new sap.ui.model.Filter("IDATE", sap.ui.model.FilterOperator.BT, sDateFrom, sDateTo);
		this.getView().getModel().read("/ExcelDataSet", {
			filters: [oFilterKey],
			success: function (oData) {
				aProducts = oData.results;
				oSettings = {
					workbook: {
						columns: aCols
					},
					dataSource: aProducts,
					showProgress: true
				};
				oSettings.dataSource.sizeLimit = aProducts.length;
				sap.ui.require(["sap/ui/export/Spreadsheet"], function (Spreadsheet) {
					oSheet = new Spreadsheet(oSettings);
					oSheet.build()
						.then(function () {
							sap.m.MessageToast.show('Spreadsheet export has finished');
						})
						.finally(function () {
							oSheet.destroy();
						});
				});
			}.bind(this),

			error: function (oError) {
				var oError = oError;
			}.bind(this)
		});
	},

	createColumnConfig: function () {
		return [{
			label: 'Nomination Number',
			property: 'NOMNR',
			type: 'number'
		}, {
			label: 'Nomintion Ticket',
			property: 'Nomtk',
			width: '25',
			type: 'number'
		}, {
			label: 'Event Number',
			property: 'Event_nr',
			width: '25'
		}, {
			label: 'Nomination Item',
			property: 'Nomit',
			width: '18'
		}, {
			label: 'Location',
			property: 'LOCNAM',
			width: '18'
		}, {
			label: 'Schedule Date',
			property: 'IDATE',
			width: '18'
		}, {
			label: 'Scheduled Material',
			property: 'S_MATNR_I',
			width: '18'
		}, {
			label: 'Scheduled Quantity',
			property: 'MENGE',
			width: '18'
		}, {
			label: 'UOM',
			property: 'UNIT_I',
			width: '18'
		}, {
			label: 'Actual Quantity',
			property: 'ACTUALQTY',
			width: '18'
		}, {
			label: 'Actual UOM',
			property: 'ACTUALUOM',
			width: '18'
		}, {
			label: 'Actual Quantity in MT',
			property: 'QtyMt',
			width: '18'
		}, {
			label: 'UOM MT',
			property: 'UOMMt',
			width: '18'
		}, {
			label: 'Actual Qunatity in M3',
			property: 'QtyM3',
			width: '18'
		}, {
			label: 'UOM M3',
			property: 'UOMM3',
			width: '18'
		}, {
			label: 'Vehicle Number',
			property: 'NMVEHICLE',
			width: '18'
		}, {
			label: 'Vehicle Text',
			property: 'VEH_TEXT',
			width: '18'
		}, {
			label: 'Vehicle IMO Number',
			property: 'NMVESSEL',
			width: '18'
		}, {
			label: 'Carrier',
			property: 'NMCARRIER',
			width: '18'
		}, {
			label: 'Carrier Text',
			property: 'CARRIERTXT',
			width: '18'
		}, {
			label: 'Consignee Partner',
			property: 'CONS',
			width: '18'
		}, {
			label: 'Consignee Text',
			property: 'CONS_TXT',
			width: '18'
		}, {
			label: 'Inspector',
			property: 'INSPE',
			width: '18'
		}, {
			label: 'Inspector Text',
			property: 'INSPE_TXT',
			width: '18'
		}, {
			label: 'Transport System',
			property: 'TSYST',
			width: '18'
		}, {
			label: 'Mode of Transport',
			property: 'VKTRA',
			width: '18'
		}, {
			label: 'Mode of Transport Text',
			property: 'Transtxt',
			width: '18'
		}, {
			label: 'Incoterm',
			property: 'INCO1',
			width: '18'
		}, {
			label: 'Incoterm 2',
			property: 'INCO2',
			width: '18'
		}, {
			label: 'Reference Doc No',
			property: 'DOCNR',
			width: '18'
		}, {
			label: 'Reference Doc Item',
			property: 'DOCITM',
			width: '18'
		}, {
			label: 'Reference Doc Type',
			property: 'DocTyp',
			width: '18'
		}, {
			label: 'Letter of Credit',
			property: 'LetterCred',
			width: '18'
		}, {
			label: 'Schedule Type',
			property: 'SchTyp',
			width: '18'
		}, {
			label: 'Reference Doc Indicator',
			property: 'RefDocInd',
			width: '18'
		}, {
			label: 'Nomination Type',
			property: 'NomTyp',
			width: '18'
		}, {
			label: 'Nomination Type Text',
			property: 'NomTypTxt',
			width: '18'
		}, {
			label: 'Status',
			property: 'NomStat',
			width: '18'
		}, {
			label: 'Created On',
			property: 'CreatedOn',
			width: '18'
		}, {
			label: 'Created Time',
			property: 'CreationTime',
			width: '18'
		}, {
			label: 'Created By',
			property: 'CreatedBy',
			width: '18'
		}, {
			label: 'Changed On',
			property: 'Nomit',
			width: '18'
		}, {
			label: 'In transit Plant',
			property: 'TransitPlnt',
			width: '18'
		}, {
			label: 'In Trans. Storage Loc',
			property: 'TransitLoc',
			width: '18'
		}, {
			label: 'Deletion Indicator',
			property: 'DelInd',
			width: '18'
		}, {
			label: 'Item Status',
			property: 'ISTAT',
			width: '18'
		}, {
			label: 'Nomination General Comments',
			property: 'Commnt',
			width: '18'
		}, {
			label: 'Tanks Nominated',
			property: 'TanksNom',
			width: '18'
		}, {
			label: 'Ticket Status',
			property: 'TickStat',
			width: '18'
		}, {
			label: 'Number of Tickets',
			property: 'TicketNo',
			width: '18'
		}, {
			label: 'Events',
			property: 'Events',
			width: '18'
		}, {
			label: 'Qty Tolerance Over(%)',
			property: 'QtyToleranceOver',
			width: '18'
		}, {
			label: 'Qty Tolerance Under(%)',
			property: 'QtyToleranceUnder',
			width: '18'
		}, {
			label: 'Application Code',
			property: 'NomApp',
			width: '18'
		}, {
			label: 'Tank Number',
			property: 'TankNumber',
			width: '18'
		}, {
			label: 'Opening Dip Date',
			property: 'OpeningDipDate',
			width: '18'
		}, {
			label: 'Opening Dip Time',
			property: 'OpeningDipTime',
			width: '18'
		}, {
			label: 'Opening Dip',
			property: 'OpeningDip',
			width: '18'
		}, {
			label: 'Closing Dip Date',
			property: 'ClosingDipDate',
			width: '18'
		}, {
			label: 'Closing Dip Time',
			property: 'ClosingDipTime',
			width: '18'
		}, {
			label: 'Closing Dip',
			property: 'ClosingDip',
			width: '18'
		}, {
			label: 'Actual Posted Qty',
			property: 'ActualPostQty',
			width: '18'
		}, {
			label: 'Actual Posted Qty UOM',
			property: 'ActualUom',
			width: '18'
		}, {
			label: 'Actual Date',
			property: 'ActualDate',
			width: '18'
		}, {
			label: 'Actual Time',
			property: 'ActualTime',
			width: '18'
		}, {
			label: 'Ticket Key',
			property: 'TicketKey',
			width: '18'
		}, {
			label: 'Ticket Item No.',
			property: 'TicketItem',
			width: '18'
		}, {
			label: 'Deletion Indicator Tanks',
			property: 'DelIndicator',
			width: '18'
		}, {
			label: 'Event Number',
			property: 'Event_nr',
			width: '18'
		}, {
			label: 'Event Type',
			property: 'Type',
			width: '18'
		}, {
			label: 'Event Sequence',
			property: 'Ev_seq',
			width: '18'
		}, {
			label: 'Planned Start Date: From',
			property: 'Pstdtf',
			width: '18'
		}, {
			label: 'Planned Start Time:From',
			property: 'Psttmf',
			width: '18'
		}, {
			label: 'Planned End Date:To',
			property: 'Peddtt',
			width: '18'
		}, {
			label: 'Planned End Time:To',
			property: 'Pedtmt',
			width: '18'
		}, {
			label: 'Actual Start Date:From',
			property: 'Astdtf',
			width: '18'
		}, {
			label: 'Actual Start Time:From',
			property: 'Asttmf',
			width: '18'
		}, {
			label: 'Actual End Date:To',
			property: 'Aeddtt',
			width: '18'
		}, {
			label: 'Actual End Time:To',
			property: 'Aedtmt',
			width: '18'
		}, {
			label: 'Comments',
			property: 'EventComment',
			width: '18'
		}, {
			label: 'Ticket Type',
			property: 'TicketType',
			width: '18'
		}, {
			label: 'Ticket External Number',
			property: 'TicketNr',
			width: '18'
		}, {
			label: 'Ticket Key',
			property: 'TktTicketKey',
			width: '18'
		}, {
			label: 'Ticket Version',
			property: 'TicketVersion',
			width: '18'
		}, {
			label: 'Purpose',
			property: 'TicketPurpose',
			width: '18'
		}, {
			label: 'Ticket Created On',
			property: 'TktCreatedOn',
			width: '18'
		}, {
			label: 'Ticket Created By',
			property: 'TktCreatedBy',
			width: '18'
		}, {
			label: 'Status Description',
			property: 'StatusDesc',
			width: '18'
		}, {
			label: 'Completion Status',
			property: 'CompletionStatus',
			width: '18'
		}, {
			label: 'Load Discharge Start',
			property: 'LoadStrt',
			width: '18'
		}, {
			label: 'Load Discharge End',
			property: 'LoadEnd',
			width: '18'
		}];
	},
	//	onPressNomNum: function(E) {
	//
	//	}
	onPressNumberOfNominationTickets: function (oEvent) {
			var nRowIndex, oBinding, sNomtk, sNomit, oCrossAppNavigator, nVisible, nSelected;
			nVisible = this._getNominationsTable().getProperty("firstVisibleRow");
			nRowIndex = oEvent.getSource().getParent().getId().match(/\d+$/);
			nSelected = parseInt(nVisible) + parseInt(nRowIndex);
			oBinding = this._getNominationsTable().getContextByIndex(nSelected);
			sNomtk = oBinding.getProperty("NominationDoc");
			sNomit = oBinding.getProperty("NominationDocItem");
			this.getRouter().navTo("Tickets", {
				nom_key: sNomtk,
				nom_item: sNomit
			});
		}
		//	onPressDocnr: function(E) {
		//
		//	}
		//	onContractPartnrConfirm: function(E) {
		//
		//	}
		//	onConsigneePartnrConfirm: function(E) {
		//
		//	}
		//	onPersonNameConfirm: function(E) {
		//
		//	}
		//	onRefDocItemConfirm: function(E) {
		//
		//	}
		//	onContractPartnrSearch: function(E) {
		//
		//	}
		//	onConsigneePartnrSearch: function(E) {
		//
		//	}
		//	onPersonNameSearch: function(E) {
		//
		//	}
		//	onNomItemTokenChange: function(E) {
		//
		//	}
		//	onCancelNomItemHelp: function(E) {
		//
		//	}
		//	onSearchNomItemHelp: function(E) {
		//
		//	}
		//	onVehicleNumTokenChange: function(E) {
		//
		//	}
		//	onCancelVehicleNumHelp: function(E) {
		//
		//	}
		//	onCancelRefDocItemHelp: function(E) {
		//
		//	}
		//	onCancelShipperHelp: function(E) {
		//
		//	}
		//	onCancelCarrierHelp: function(E) {
		//
		//	}
		//	onPersonNameTokenChange: function(E) {
		//
		//	}
		//	onCancelPersonNameHelp: function(E) {
		//
		//	}
		//	onSearchPersonNameHelp: function(E) {
		//
		//	}
		//	onConfirmNomItemHelp: function(E) {
		//
		//	}
		//	onConfirmVehicleNumHelp: function(E) {
		//
		//	}
		//	onConfirmImpoExpoHelp: function(E) {
		//
		//	}
		//	onSearchVehicleNumHelp: function(E) {
		//
		//	}
		//	onImpoExpoTokenChange: function(E) {
		//
		//	}
		//	onCancelImpoExpoHelp: function(E) {
		//
		//	}
		//	onSearchImpoExpoHelp: function(E) {
		//
		//	}
		//	onShipperTokenChange: function(E) {
		//
		//	}
		//	onCarrierTokenChange: function(E) {
		//
		//	}
		//	onSearchShipperHelp: function(E) {
		//
		//	}
		//	onSearchCarrierHelp: function(E) {
		//
		//	}
		//	onRefDocItemSearch: function(E) {
		//
		//	}
		//	onHandleConfirm: function(E) {
		//
		//	}
		//	onNomNumValueHelp: function(E) {
		//
		//	}
		//	onNomKeyValueHelp: function(E) {
		//
		//	}
		//	onNomTypeValueHelp: function(E) {
		//
		//	}
		//	onNomItemValueHelp: function(E) {
		//
		//	}
		//	onInspectorValueHelp: function(E) {
		//
		//	}
		//	onLocationPrtnrValueHelp: function(E) {
		//
		//	}
		//	onStatusValueHelp: function(E) {
		//
		//	}
		//	onDocnrValueHelp: function(E) {
		//
		//	}
		//	onDocnrTokenChange: function(E) {
		//
		//	}
		//	onConfirmDocnrHelp: function(E) {
		//
		//	}
		//	onCancelDocnrHelp: function(E) {
		//
		//	}
		//	onSearchDocnrHelp: function(E) {
		//
		//	}
		//	onInTransitPlantValueHelp: function(E) {
		//
		//	}
		//	onInTransitPlantTokenChange: function(E) {
		//
		//	}
		//	onConfirmInTransitPlantHelp: function(E) {
		//
		//	}
		//	onCancelInTransitPlantHelp: function(E) {
		//
		//	}
		//	onSearchInTransitPlantHelp: function(E) {
		//
		//	}
		//	onInTransitLocValueHelp: function(E) {
		//
		//	}
		//	onInTransitLocTokenChange: function(E) {
		//
		//	}
		//	onConfirmInTransitLocHelp: function(E) {
		//
		//	}
		//	onCancelInTransitLocHelp: function(E) {
		//
		//	}
		//	onSearchInTransitLocHelp: function(E) {
		//
		//	}
		//	onStatusTokenChange: function(E) {
		//
		//	}
		//	onConfirmStatusHelp: function(E) {
		//
		//	}
		//	onCancelStatusHelp: function(E) {
		//
		//	}
		//	onSearchStatusHelp: function(E) {
		//
		//	}
		//	onLocationPrtnrTokenChange: function(E) {
		//
		//	}
		//	onLocationPartnrConfirm: function(E) {
		//
		//	}
		//	onCancelLocationPartnr: function(E) {
		//
		//	}
		//	onLocationPartnrSearch: function(E) {
		//
		//	}
		//	onInspectorTokenChange: function(E) {
		//
		//	}
		//	onConfirmInspectorHelp: function(E) {
		//
		//	}
		//	onCancelInspectorHelp: function(E) {
		//
		//	}
		//	onInspectorSearch: function(E) {
		//
		//	}
		//	onIstatValueHelp: function(E) {
		//
		//	}
		//	onIstatTokenChange: function(E) {
		//
		//	}
		//	onConfirmIstatHelp: function(E) {
		//
		//	}
		//	onCancelIstatHelp: function(E) {
		//
		//	}
		//	onSearchIstatHelp: function(E) {
		//
		//	}
		//	onFlagImexValueHelp: function(E) {
		//
		//	}
		//	onUoMValueHelp: function(E) {
		//
		//	}
		//	onImpoExpoValueHelp: function(E) {
		//
		//	}
		//	onPersonNameValueHelp: function(E) {
		//
		//	}
		//	onVehicleNumValueHelp: function(E) {
		//
		//	}
		//	onLocIdValueHelp: function(E) {
		//
		//	}
		//	onTransportPlanningPtValueHelp: function(E) {
		//
		//	}
		//	onShipperValueHelp: function(E) {
		//
		//	}
		//	onCarrierValueHelp: function(E) {
		//
		//	}
		//	onMaterialValueHelp: function(E) {
		//
		//	}
		//	onValuationtype_dValueHelp: function(E) {
		//
		//	}
		//	onValuationtype_dTokenChange: function(E) {
		//
		//	}
		//	onConfirmValTypDHelp: function(E) {
		//
		//	}
		//	onCancelValTypDHelp: function(E) {
		//
		//	}
		//	onSearchValTypDHelp: function(E) {
		//
		//	}
		//	onTsystValueHelp: function(E) {
		//
		//	}
		//	onTsystTokenChange: function(E) {
		//
		//	}
		//	onConfirmTsystHelp: function(E) {
		//
		//	}
		//	onCancelTsystHelp: function(E) {
		//
		//	}
		//	onSearchTsystHelp: function(E) {
		//
		//	}
		//	_getTsystValueHelp: function(E) {
		//
		//	}
		//	_getTsystValueHelpId: function() {
		//
		//	}
		//	onValuationtype_oValueHelp: function(E) {
		//
		//	}
		//	onSchldMaterialValueHelp: function(E) {
		//
		//	}
		//	onSchldMaterialTokenChange: function(E) {
		//
		//	}
		//	onConfirmSchldMaterialHelp: function(E) {
		//
		//	}
		//	onCancelSchldMaterialHelp: function(E) {
		//
		//	}
		//	onSearchSchldMaterialHelp: function(E) {
		//
		//	}
		//	_getSchldMaterialValueHelp: function(E) {
		//
		//	}
		//	_getSchldMaterialValueHelpId: function() {
		//
		//	}
		//	onValuationtype_oTokenChange: function(E) {
		//
		//	}
		//	onConfirmValTypOHelp: function(E) {
		//
		//	}
		//	onCancelValTypOHelp: function(E) {
		//
		//	}
		//	onSearchValTypOHelp: function(E) {
		//
		//	}
		//	_getValuationtype_oValueHelp: function(E) {
		//
		//	}
		//	_getValuationtype_oValueHelpId: function() {
		//
		//	}
		//	onContractPrtnrValueHelp: function(E) {
		//
		//	}
		//	onConsigneePrtnrValueHelp: function(E) {
		//
		//	}
		//	onRefDocItemValueHelp: function(E) {
		//
		//	}
		//	onSitypValueHelp: function(E) {
		//
		//	}
		//	onSitypTokenChange: function(E) {
		//
		//	}
		//	onConfirmSitypHelp: function(E) {
		//
		//	}
		//	onCancelSitypHelp: function(E) {
		//
		//	}
		//	onSearchSitypHelp: function(E) {
		//
		//	}
		//	_getSitypValueHelp: function(E) {
		//
		//	}
		//	_getSitypValueHelpId: function() {
		//
		//	}
		//	onSearchNomNumHelp: function(E) {
		//
		//	}
		//	onSearchFlagImexHelp: function(E) {
		//
		//	}
		//	onConfirmUoMHelp: function(E) {
		//
		//	}
		//	onUoMTokenChange: function(E) {
		//
		//	}
		//	onCancelUoMHelp: function(E) {
		//
		//	}
		//	onSearchUoMHelp: function(E) {
		//
		//	}
		//	onConfirmNomNumHelp: function(E) {
		//
		//	}
		//	onConfirmNomKeyHelp: function(E) {
		//
		//	}
		//	onConfirmFlagImexHelp: function(E) {
		//
		//	}
		//	onConfirmLocIdHelp: function(E) {
		//
		//	}
		//	onConfirmShipperHelp: function(E) {
		//
		//	}
		//	onConfirmCarrierHelp: function(E) {
		//
		//	}
		//	onTransportPlanningPtTokenChange: function(E) {
		//
		//	}
		//	onNomTypeTokenChange: function(E) {
		//
		//	}
		//	onCancelNomtypHelp: function(E) {
		//
		//	}
		//	onSearchNomtypHelp: function(E) {
		//
		//	}
		//	onCancelTransportPlanningPtHelp: function(E) {
		//
		//	}
		//	onConfirmTransportPlanningPtHelp: function(E) {
		//
		//	}
		//	onConfirmNomtypHelp: function(E) {
		//
		//	}
		//	onSearchTransportPlanningPtHelp: function(E) {
		//
		//	}
		//	onConfirmMaterialHelp: function(E) {
		//
		//	}
		//	onNomNumTokenChange: function(E) {
		//
		//	}
		//	onNomKeyTokenChange: function(E) {
		//
		//	}
		//	onCancelNomKeyHelp: function(E) {
		//
		//	}
		//	onSearchNomKeyHelp: function(E) {
		//
		//	}
		//	onMaterialTokenChange: function(E) {
		//
		//	}
		//	onFlagImexTokenChange: function(E) {
		//
		//	}
		//	onLocIdTokenChange: function(E) {
		//
		//	}
		//	onSearchLocIdHelp: function(E) {
		//
		//	}
		//	onSearchMaterialHelp: function(E) {
		//
		//	}
		//	onCancelNomNumHelp: function(E) {
		//
		//	}
		//	onCancelConsigneePartnr: function(E) {
		//
		//	}
		//	onCancelContractPartner: function(E) {
		//
		//	}
		//	onCancelLocIdHelp: function(E) {
		//
		//	}
		//	onCancelMaterialHelp: function(E) {
		//
		//	}
		//	onCancelFlagImexHelp: function(E) {
		//
		//	}
		//	onNominationsSelectionChange: function(E) {
		//
		//	}
		//	onUserPreferences: function(E) {
		//
		//	}
		//	onPressChange: function(E) {
		//
		//	}
		//	_onEditBatchSuccess: function(f, C) {
		//
		//	}
		//	_onEditBatchError: function(E) {
		//
		//	}
		//	onSortNominationsTable: function(E) {
		//
		//	}
		//	onFilterNominationsTable: function(E) {
		//
		//	}
		//	onPressCopyAdvanced: function(E) {
		//
		//	}
		//	onPressCopy: function(E) {
		//
		//	}
		//	onPreferenceConfirm: function(E) {
		//
		//	}
		//	onPreferenceCountChange: function(E) {
		//
		//	}
		//	onPreferenceCancel: function(E) {
		//
		//	}
		//	onSortNominations: function() {
		//
		//	}
		//	onFreeSearch: function(E) {
		//
		//	}
		//	onChange: function(E) {
		//
		//	}
		//	onClear: function(E) {
		//
		//	}
		//	_getNomNumValueHelp: function(E) {
		//
		//	}
		//	_getNomNumValueHelpId: function() {
		//
		//	}
		//	_getNomItemValueHelp: function(E) {
		//
		//	}
		//	_getNomItemValueHelpId: function() {
		//
		//	}
		//	_getValuationtype_dValueHelp: function(E) {
		//
		//	}
		//	_getValuationtype_dValueHelpId: function() {
		//
		//	}
		//	_getInTransitPlantValueHelp: function(E) {
		//
		//	}
		//	_getInTransitPlantValueHelpId: function() {
		//
		//	}
		//	_getPersonNameValueHelp: function(E) {
		//
		//	}
		//	_getPersonNameValueHelpId: function() {
		//
		//	}
		//	_getNomKeyValueHelp: function(E) {
		//
		//	}
		//	_getNomKeyValueHelpId: function() {
		//
		//	}
		//	_getFlagImexValueHelp: function(E) {
		//
		//	}
		//	_getFlagImexValueHelpId: function() {
		//
		//	}
		//	_getLocIdValueHelp: function(E) {
		//
		//	}
		//	_getLocIdValueHelpId: function() {
		//
		//	}
		//	_getVehicleNumValueHelp: function(E) {
		//
		//	}
		//	_getVehicleNumValueHelpId: function() {
		//
		//	}
		//	_getImpoExpoValueHelp: function(E) {
		//
		//	}
		//	_getImpoExpoValueHelpId: function() {
		//
		//	}
		//	_getMaterialValueHelp: function(E) {
		//
		//	}
		//	_getMaterialValueHelpId: function() {
		//
		//	}
		//	_getContractPartnerValueHelp: function(E) {
		//
		//	}
		//	_getContractPartnerValueHelpId: function() {
		//
		//	}
		//	_getConsigneePrtnrValueHelp: function(E) {
		//
		//	}
		//	_getConsigneePartnerValueHelpId: function() {
		//
		//	}
		//	_getUoMValueHelp: function(E) {
		//
		//	}
		//	_getUoMValueHelpId: function() {
		//
		//	}
		//	_getLocationPrtnrValueHelp: function(E) {
		//
		//	}
		//	_getLocationPrtnrValueHelpId: function() {
		//
		//	}
		//	_getDocnrValueHelp: function(E) {
		//
		//	}
		//	_getDocnrValueHelpId: function() {
		//
		//	}
		//	_getTransportPlanningPtValueHelp: function(E) {
		//
		//	}
		//	_getTransportPlanningPtValueHelpId: function() {
		//
		//	}
		//	_getInTransitLocValueHelp: function(E) {
		//
		//	}
		//	_getInTransitLocValueHelpId: function() {
		//
		//	}
		//	_getIstatValueHelp: function(E) {
		//
		//	}
		//	_getIstatValueHelpId: function() {
		//
		//	}
		//	_getNominationTypeValueHelp: function(E) {
		//
		//	}
		//	_getNominationTypeValueHelpId: function() {
		//
		//	}
		//	_getStatusValueHelp: function(E) {
		//
		//	}
		//	_getStatusValueHelpId: function() {
		//
		//	}
		//	_getRefDocItemValueHelp: function(E) {
		//
		//	}
		//	_getRefDocItemValueHelpId: function() {
		//
		//	}
		//	_getShipperValueHelp: function(E) {
		//
		//	}
		//	_getCarrierValueHelp: function(E) {
		//
		//	}
		//	_getShipperValueHelpId: function() {
		//
		//	}
		//	_getCarrierValueHelpId: function() {
		//
		//	}
		//	_getInspectorValueHelp: function(E) {
		//
		//	}
		//	_getInspectorValueHelpId: function() {
		//
		//	}
		//	_fnHandleSuccessUserPrefRead: function(f, r) {
		//
		//	}
		//	_fnHandleErrorUserPrefRead: function(E) {
		//
		//	}
		//	_fnMessageLogReadSuccess: function(f, r) {
		//
		//	}
		//	_fnMessageLogReadError: function(E) {
		//
		//	}
		//	_fnFetchData: function() {
		//
		//	}
		//	_fnFilterValidaton: function(f) {
		//
		//	}
		//	_fnApplyData: function(j) {
		//
		//	}
		//	_fnGetFiltersWithValues: function() {
		//
		//	}
		//	_fnNominationsDataReceived: function(E) {
		//
		//	}
		//	_fnGetSelectedNominations: function() {
		//
		//	}
		//	_fnDefaultAdvPreferences: function(E) {
		//
		//	}
		//	_fnGetNominationsCount: function() {
		//
		//	}
		//	_fnAddToNominationsCount: function(f) {
		//
		//	}
		//	_fnClearNominationsCount: function() {
		//
		//	}
		//	_getSearchFilter: function() {
		//
		//	}
		//	_getTableFilter: function() {
		//
		//	}
		//	_fnCreateFilters: function(f) {
		//
		//	}
		//	_fnGetFiltersForItem: function(I, f) {
		//
		//	}
		//	_getNominationsTable: function() {
		//
		//	}
		//	variantControl: function() {
		//
		//	}
		//	_getSortDialog: function() {
		//
		//	}
		//	_getPreferencesDialog: function() {
		//
		//	}
		//	_getPreferenceId: function(E) {
		//
		//	}
		//	_fnParseDateFormat: function(f) {
		//
		//	}
		//	_getNominationItemFilterItem: function(E) {
		//
		//	}
		//	_getNominationKeyFilterItem: function(E) {
		//
		//	}
		//	_getNomNumFilter: function() {
		//
		//	}
		//	_getLocIdFilter: function() {
		//
		//	}
		//	_getScheduledMaterialFilter: function() {
		//
		//	}
		//	_getTransportSystemFilter: function() {
		//
		//	}
		//	_getNomTypeFilter: function() {
		//
		//	}
		//	_getNomKeyFilter: function() {
		//
		//	}
		//	_getNomItemFilter: function() {
		//
		//	}
		//	_getPersonNameFilter: function() {
		//
		//	}
		//	_getUoMFilter: function() {
		//
		//	}
		//	_getValuationTypeDFilter: function() {
		//
		//	}
		//	_getValuationTypeOFilter: function() {
		//
		//	}
		//	_getStatusFilter: function() {
		//
		//	}
		//	_getSchldTypeFilter: function() {
		//
		//	}
		//	_getNomStatusFilter: function() {
		//
		//	}
		//	_getTransportPlanningPointFilter: function() {
		//
		//	}
		//	_getVehicleNumFilter: function() {
		//
		//	}
		//	_getMaterialFilter: function() {
		//
		//	}
		//	_getContractPartnerFilter: function() {
		//
		//	}
		//	_getInspectorFilter: function() {
		//
		//	}
		//	_getLocationPartnerFilter: function() {
		//
		//	}
		//	_getShipperFilter: function() {
		//
		//	}
		//	_getCarrierFilter: function() {
		//
		//	}
		//	_getConsigneePartnerFilter: function() {
		//
		//	}
		//	_getDocnrFilter: function() {
		//
		//	}
		//	_getInTransitLocationFilter: function() {
		//
		//	}
		//	_getInTransitPlantFilter: function() {
		//
		//	}
		//	_getRefDocItemFilter: function() {
		//
		//	}
		//	_getImpoExpoFilter: function() {
		//
		//	}
		//	_getFlagImexFilter: function() {
		//
		//	}
		//	_getSortId: function() {
		//
		//	}
		//	_getFilterBar: function() {
		//
		//	}
		//	_getfilterName: function(f) {
		//
		//	}
		//	afterVariantSave: function(E) {
		//
		//	}
		//	filterParams: function(f) {
		//
		//	}
		//	setAppState: function() {
		//
		//	}

});