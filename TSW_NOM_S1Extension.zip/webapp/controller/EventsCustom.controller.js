sap.ui.define([
	"oil/tsw/mynominationss1/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/table/TablePersoController",
	"sap/ui/core/routing/History",
	"sap/ui/core/Fragment",
	"sap/m/MessageToast",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"oil/tsw/mynominationss1/model/formatter",
	"sap/ui/export/Spreadsheet"
], function (B, J, M, T, H, F, a, b, c, d, FilterOperator, f, Spreadsheet) {
	"use strict";
	var m = new sap.ui.core.message.ControlMessageProcessor();
	var o = sap.ui.getCore().getMessageManager();
	o.registerMessageProcessor(m);
	return sap.ui.controller("oil.tsw.mynominationss1.TSW_NOM_S1Extension.controller.EventsCustom", {
		formatter: f,
		onInit: function () {
			o.removeAllMessages();
			this.getOwnerComponent().fnSetNominationsModified(true);
			sap.ui.core.UIComponent.getRouterFor(this).attachRouteMatched(function (e) {
				if (e.getParameter("name") === "Events") {
					var n = e.getParameter("arguments").nom_key;
					var g = e.getParameter("arguments").nom_item;
				}

				var oDataModel = this.getOwnerComponent().getModel();
				var oFilterKey = new d("Nomtk", FilterOperator.EQ, n);
				var oFilterItem = new d("Nomit", FilterOperator.EQ, g);
				var oFilterAll = new d({
					filters: [oFilterKey, oFilterItem],
					and: true
				});
				oDataModel.read("/EventSet", {
					filters: [oFilterAll],
					success: function (oData) {
						var oDataLcal = oData;
						var oLocalModel = new J(oData.results);
						this.getView().setModel(oLocalModel, "localModel");
						this.getView().byId("idEventTable").bindRows("localModel>/");
					}.bind(this),
					error: function (error) {
						var oError = error;
					}
				});
				var u = {
					nomdocKey: n,
					nomitemKey: g
				};
				var U = new J(u);
				this.getView().setModel(U, "UIModel");
			}, this);

		}
	});
});